#!/bin/bash

# 演習用ディレクトリ
DIRNAME="./archive"

# 演習環境削除
rm -rf ${DIRNAME}

# 演習環境作成
mkdir ${DIRNAME}
mkdir ${DIRNAME}/dir1

for i in `seq 3`
do
    base64 /dev/urandom | head -c 5M > ${DIRNAME}/file${i}.txt
    base64 /dev/urandom | head -c 5M > ${DIRNAME}/dir1/dir1-file${i}.txt
done
