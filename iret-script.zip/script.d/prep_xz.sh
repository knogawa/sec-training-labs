#!/bin/bash

# 演習用ディレクトリ
DIRNAME="./xz"

# 演習環境削除
rm -rf ${DIRNAME}

# 演習環境作成
mkdir ${DIRNAME}
for i in `seq 3`
do
    base64 /dev/urandom | head -c 5M > ${DIRNAME}/xz-text${i}.txt
done
