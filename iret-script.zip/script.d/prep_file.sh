#!/bin/bash

# 演習用ディレクトリ
DIRNAME="./file"

# 演習環境削除
rm -rf ${DIRNAME}

# 演習環境作成
mkdir ${DIRNAME}
touch ${DIRNAME}/file{1,2}.txt
touch ${DIRNAME}/.hidden-file{1,2}.txt
mkdir ${DIRNAME}/dir{1,2}
touch ${DIRNAME}/dir1/dir1-file{1,2}.txt
touch ${DIRNAME}/dir2/dir2-file{1,2}.txt
ln -s file1.txt ${DIRNAME}/link1
