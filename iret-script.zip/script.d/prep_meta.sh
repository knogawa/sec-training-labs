#!/bin/bash

# 演習用ディレクトリ
DIRNAME="./file_meta"

# 演習環境削除
rm -rf ${DIRNAME}

# 演習環境作成
mkdir ${DIRNAME}
touch ${DIRNAME}/m{1,2,3}.txt
touch ${DIRNAME}/M{1,2,3}.txt
touch ${DIRNAME}/a.txt
touch ${DIRNAME}/aa.txt
touch ${DIRNAME}/aaa.txt
touch ${DIRNAME}/aaaa.txt
touch ${DIRNAME}/ab.txt
touch ${DIRNAME}/aba.txt
touch ${DIRNAME}/abb.txt
touch ${DIRNAME}/abc.txt
touch ${DIRNAME}/ac.txt
touch ${DIRNAME}/aca.txt
touch ${DIRNAME}/acb.txt
touch ${DIRNAME}/acc.txt

