#!/bin/bash

# 演習用ディレクトリ
DIRNAME="./file_find"

# 演習環境削除
rm -rf ${DIRNAME}

# 演習環境作成
mkdir ${DIRNAME}

for i in `seq 15`
do
    DATE=`date +%Y%m%d%H%M -d "${i} days ago"`
    touch -t ${DATE} ${DIRNAME}/find_${DATE}.txt
done
