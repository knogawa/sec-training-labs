#!/bin/bash

# 演習用ディレクトリ
DIRNAME="./chown"

# 演習環境削除
rm -rf ${DIRNAME}

# 演習環境作成
mkdir ${DIRNAME}
touch ${DIRNAME}/file{1,2,3,4,5}.txt
mkdir ${DIRNAME}/dir1
touch ${DIRNAME}/dir1/dir1-file{1,2,3}.txt
