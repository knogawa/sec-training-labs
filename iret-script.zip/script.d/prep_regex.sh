#!/bin/bash

# 演習用ディレクトリ
DIRNAME="./regexp"

# 演習環境削除
rm -rf ${DIRNAME}

# 演習環境作成
mkdir ${DIRNAME}
cat > ${DIRNAME}/file1.txt << EOF
lemon orange banana melon lemon
orange banana melon lemon orange
banana melon lemon orange banana
melon lemon orange banana melon
LEMON ORANGE BANANA MELON LEMON
ORANGE BANANA MELON LEMON ORANGE
BANANA MELON LEMON ORANGE BANANA
MELON LEMON ORANGE BANANA MELON
EOF
