#!/bin/bash

# 演習用ディレクトリ
DIRNAME="./rpm"

# 演習環境削除
rm -rf ${DIRNAME}

# 演習環境作成
mkdir ${DIRNAME}
cd ${DIRNAME}

# rsync
curl -skLO https://repo.almalinux.org/vault/9.0/BaseOS/x86_64/os/Packages/rsync-3.2.3-9.el9.x86_64.rpm
curl -sLO http://ftp.riken.jp/Linux/almalinux/9/BaseOS/x86_64/os/Packages/rsync-3.2.3-20.el9.x86_64.rpm

# lsof
curl -sLO http://ftp.riken.jp/Linux/almalinux/9/BaseOS/x86_64/os/Packages/lsof-4.94.0-3.el9.x86_64.rpm
curl -sLO http://ftp.riken.jp/Linux/almalinux/9/BaseOS/x86_64/os/Packages/libtirpc-1.3.3-9.el9.x86_64.rpm

